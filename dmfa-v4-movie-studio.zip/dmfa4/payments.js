// Paystack: credit packs + 30-day Pro pass. Credits are granted only after server-side verification.
const express = require('express');
const crypto = require('crypto');
const { pool, withUser } = require('./db');
const C = require('./credits');

const CURRENCY = process.env.CURRENCY || 'NGN';
const PACKS = {
  starter: { label: 'Starter', credits: 3000,  amount: +process.env.PRICE_STARTER || 1500 },
  creator: { label: 'Creator', credits: 10000, amount: +process.env.PRICE_CREATOR || 4000 },
  pro:     { label: 'Pro (30 days)', pro: true, amount: +process.env.PRICE_PRO || 7500 }
};
const PS = 'https://api.paystack.co';
const H = () => ({ Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json' });

// Verifies with Paystack and, if paid, grants once. Safe to call many times.
async function settle(reference) {
  const pr = await pool.query('SELECT * FROM payments WHERE reference=$1', [reference]);
  const p = pr.rows[0];
  if (!p) return { status: 'ignored' };
  if (p.status === 'paid') return { status: 'success', message: 'Already added.' };
  const pack = PACKS[p.pack];
  const r = await fetch(`${PS}/transaction/verify/${encodeURIComponent(reference)}`, { headers: H() });
  const d = ((await r.json()).data) || {};
  if (d.status === 'abandoned' || d.status === 'failed') {
    await pool.query("UPDATE payments SET status='failed' WHERE reference=$1 AND status='pending'", [reference]);
    return { status: 'failed' };
  }
  if (d.status !== 'success') return { status: 'pending' };
  if (d.amount !== pack.amount * 100 || d.currency !== CURRENCY) { console.error('amount mismatch', reference); return { status: 'failed' }; }
  const msg = await withUser(p.user_id, async (u, c) => {
    const claim = await c.query("UPDATE payments SET status='paid' WHERE reference=$1 AND status='pending' RETURNING reference", [reference]);
    if (!claim.rowCount) return 'Already added.';
    if (pack.pro) { C.grantPro(u, Date.now() + 30 * 24 * 3600 * 1000); return 'Pro activated for 30 days!'; }
    C.addCredits(u, pack.credits); return `${pack.credits} credits added!`;
  });
  return { status: 'success', message: msg };
}

function build(requireAuth) {
  const r = express.Router();

  r.post('/init', requireAuth, async (req, res) => {
    const pack = PACKS[req.body.pack];
    if (!pack) return res.status(400).json({ error: 'Unknown pack.' });
    try {
      const u = await pool.query('SELECT email FROM users WHERE id=$1', [req.uid]);
      const reference = 'dmfa_' + crypto.randomBytes(8).toString('hex');
      const p = await fetch(`${PS}/transaction/initialize`, {
        method: 'POST', headers: H(),
        body: JSON.stringify({
          email: u.rows[0].email, amount: pack.amount * 100, currency: CURRENCY, reference,
          callback_url: (process.env.PUBLIC_URL || '').replace(/\/$/, '') + '/'
        })
      });
      const j = await p.json();
      if (!p.ok || !j.status) throw new Error(j.message || 'init failed');
      await pool.query('INSERT INTO payments (reference, user_id, pack, created_at) VALUES ($1,$2,$3,$4)', [reference, req.uid, req.body.pack, Date.now()]);
      res.json({ url: j.data.authorization_url, reference });
    } catch (e) { console.error('pay init', e.message); res.status(502).json({ error: 'Could not start payment. Try again.' }); }
  });

  r.post('/verify', requireAuth, async (req, res) => {
    const ref = String(req.body.reference || '');
    try {
      const own = await pool.query('SELECT 1 FROM payments WHERE reference=$1 AND user_id=$2', [ref, req.uid]);
      if (!own.rowCount) return res.json({ status: 'ignored', ...(await withUser(req.uid, u => C.view(u))) });
      const out = await settle(ref);
      res.json({ ...out, ...(await withUser(req.uid, u => C.view(u))) });
    } catch (e) { console.error('pay verify', e.message); res.status(502).json({ error: 'Could not verify payment yet.' }); }
  });

  // Paystack calls this even if the customer closes the browser. Set it in Paystack dashboard: PUBLIC_URL/api/pay/webhook
  r.post('/webhook', async (req, res) => {
    const sig = crypto.createHmac('sha512', process.env.PAYSTACK_SECRET_KEY || '').update(req.rawBody || '').digest('hex');
    if (sig !== req.get('x-paystack-signature')) return res.sendStatus(401);
    res.sendStatus(200);
    try { if (req.body.event === 'charge.success') await settle(req.body.data.reference); } catch (e) { console.error('webhook', e.message); }
  });
  return r;
}
module.exports = build;
module.exports.PACKS_PUBLIC = () => Object.entries(PACKS).map(([id, p]) => ({ id, label: p.label, credits: p.credits || null, pro: !!p.pro, amount: p.amount }));
