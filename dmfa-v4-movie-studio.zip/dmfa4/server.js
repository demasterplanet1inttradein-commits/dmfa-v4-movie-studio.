require('dotenv').config();
for (const k of ['DATABASE_URL', 'JWT_SECRET']) if (!process.env[k]) { console.error(`Missing ${k} in environment.`); process.exit(1); }

const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { pool, init, withUser } = require('./db');
const C = require('./credits');
const { requireAuth, router: authRouter } = require('./auth');
const { checkPrompt, wrap } = require('./safety');
const { makePlan, clip } = require('./movie');

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { useDefaults: true, directives: {
  'img-src': ["'self'", 'data:', 'https:'], 'media-src': ["'self'", 'https:', 'data:'],
  'connect-src': ["'self'"], 'upgrade-insecure-requests': null } } }));
app.use(cors());
app.use(express.json({ limit: '2mb', verify: (req, _res, buf) => { req.rawBody = buf; } }));
app.use(rateLimit({ windowMs: 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false }));

const PLAN_COST = +process.env.PLAN_COST || 5;
const IMAGE_COST = +process.env.IMAGE_COST || 10;
const VIDEO_COST = +process.env.VIDEO_COST || 150;
const RUNWAY = 'https://api.dev.runwayml.com/v1';
const RH = () => ({ Authorization: `Bearer ${process.env.RUNWAY_API_KEY}`, 'X-Runway-Version': '2024-11-06', 'Content-Type': 'application/json' });
const STYLES = { '3D animation': '3D animation style', 'Cartoon': '2D cartoon style', 'Storybook': 'watercolor storybook illustration style' };

const wrapAsync = fn => (req, res) => fn(req, res).catch(e => {
  console.error(e.message);
  res.status(e.status || 500).json({ error: e.status === 401 ? 'Please log in again.' : 'Server error. Try again.' });
});
const outOfCredits = (res, view, need) => res.status(402).json({
  error: view.waitSeconds > 0 ? 'You are out of credits. Wait for the timer or upgrade to Pro.' : `Not enough credits (this step needs ${need}). Buy more or upgrade to Pro.`,
  code: 'OUT_OF_CREDITS', upgrade: true, ...view });
const spend = (uid, cost) => withUser(uid, u => { const s = C.spend(u, cost); return { ok: s.ok, view: C.view(u) }; });
const refund = (uid, cost) => withUser(uid, u => { C.refund(u, cost); return C.view(u); });

app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_, res) => res.json({ app: 'De-Master Flow AI', status: 'ok' }));
app.use('/api/auth', authRouter);
app.use('/api/pay', require('./payments')(requireAuth));
app.get('/api/config', (_, res) => res.json({
  privacyUrl: process.env.PRIVACY_URL || '', supportEmail: process.env.SUPPORT_EMAIL || '',
  costs: { plan: PLAN_COST, image: IMAGE_COST, video: VIDEO_COST }, currency: process.env.CURRENCY || 'NGN',
  styles: Object.keys(STYLES), packs: require('./payments').PACKS_PUBLIC() }));
app.get('/api/credits', requireAuth, wrapAsync(async (req, res) => res.json(await withUser(req.uid, u => C.view(u)))));

// ---------- helpers ----------
async function loadMovie(id, uid) {
  const r = await pool.query('SELECT id, title, data FROM movies WHERE id=$1 AND user_id=$2', [+id, uid]);
  return r.rows[0] || null;
}
async function loadScene(req, res) {
  const m = await loadMovie(req.params.id, req.uid);
  const i = +req.params.i;
  if (!m || !m.data.scenes[i]) { res.status(404).json({ error: 'Scene not found.' }); return null; }
  return { m, i, s: m.data.scenes[i] };
}
// Atomic single-scene patch. If onlyStatus is given, applies only when the scene is still in that status.
async function patchScene(id, i, patch, onlyStatus = null) {
  const r = await pool.query(
    `UPDATE movies SET data = jsonb_set(data, ARRAY['scenes', $2::text], (data->'scenes'->$3::int) || $4::jsonb), updated_at=$5
     WHERE id=$1 AND ($6::text IS NULL OR data->'scenes'->$3::int->>'status' = $6::text)`,
    [id, String(i), i, JSON.stringify(patch), Date.now(), onlyStatus]);
  return r.rowCount;
}

// ---------- movies ----------
app.get('/api/movies', requireAuth, wrapAsync(async (req, res) => {
  const r = await pool.query("SELECT id, title, created_at, jsonb_array_length(data->'scenes') AS scenes FROM movies WHERE user_id=$1 ORDER BY updated_at DESC LIMIT 50", [req.uid]);
  res.json({ movies: r.rows.map(x => ({ id: +x.id, title: x.title, scenes: x.scenes, createdAt: +x.created_at })) });
}));

app.get('/api/movie/:id', requireAuth, wrapAsync(async (req, res) => {
  const m = await loadMovie(req.params.id, req.uid);
  if (!m) return res.status(404).json({ error: 'Movie not found.' });
  res.json({ id: +m.id, title: m.title, style: m.data.style, scenes: m.data.scenes });
}));

app.post('/api/movie/plan', requireAuth, wrapAsync(async (req, res) => {
  const idea = String(req.body.idea || '');
  const err = checkPrompt(idea, 4000);
  if (err) return res.status(400).json({ error: err });
  const n = Math.min(10, Math.max(2, +req.body.scenes || 5));
  const style = STYLES[req.body.style] ? req.body.style : '3D animation';
  const s = await spend(req.uid, PLAN_COST);
  if (!s.ok) return outOfCredits(res, s.view, PLAN_COST);
  try {
    const plan = await makePlan(idea, n, style);
    const r = await pool.query('INSERT INTO movies (user_id, title, data, created_at, updated_at) VALUES ($1,$2,$3,$4,$4) RETURNING id',
      [req.uid, plan.title, JSON.stringify({ style, scenes: plan.scenes }), Date.now()]);
    res.json({ id: +r.rows[0].id, title: plan.title, style, scenes: plan.scenes, ...s.view });
  } catch (e) {
    console.error(e.message);
    res.status(502).json({ error: 'Could not plan the movie. Credits returned.', ...(await refund(req.uid, PLAN_COST)) });
  }
}));

app.delete('/api/movie/:id', requireAuth, wrapAsync(async (req, res) => {
  await pool.query('DELETE FROM movies WHERE id=$1 AND user_id=$2', [+req.params.id, req.uid]);
  res.json({ ok: true });
}));

// edit scene text
app.put('/api/movie/:id/scene/:i', requireAuth, wrapAsync(async (req, res) => {
  const ctx = await loadScene(req, res); if (!ctx) return;
  const visual = clip(req.body.visual, 480);
  const err = checkPrompt(visual);
  if (err) return res.status(400).json({ error: err });
  await patchScene(ctx.m.id, ctx.i, { title: clip(req.body.title, 60), visual, narration: clip(req.body.narration, 300) });
  res.json({ ok: true });
}));

// scene picture (Stability)
app.post('/api/movie/:id/scene/:i/image', requireAuth, wrapAsync(async (req, res) => {
  const ctx = await loadScene(req, res); if (!ctx) return;
  const visual = clip(req.body.visual || ctx.s.visual, 480);
  const err = checkPrompt(visual);
  if (err) return res.status(400).json({ error: err });
  const s = await spend(req.uid, IMAGE_COST);
  if (!s.ok) return outOfCredits(res, s.view, IMAGE_COST);
  try {
    const form = new FormData();
    form.append('prompt', `${visual}, ${STYLES[ctx.m.data.style] || STYLES['3D animation']}, cute, colorful, child-friendly, family safe`);
    form.append('negative_prompt', 'scary, violent, nsfw, text, watermark, deformed');
    form.append('aspect_ratio', '16:9');
    form.append('output_format', 'jpeg');
    const r = await fetch('https://api.stability.ai/v2beta/stable-image/generate/core', {
      method: 'POST', headers: { Authorization: `Bearer ${process.env.STABILITY_API_KEY}`, Accept: 'image/*' }, body: form });
    if (!r.ok) throw new Error(`Stability ${r.status}`);
    const image = `data:image/jpeg;base64,${Buffer.from(await r.arrayBuffer()).toString('base64')}`;
    await patchScene(ctx.m.id, ctx.i, { visual, image, status: 'idle', taskId: null, videoUrl: null });
    res.json({ image, ...s.view });
  } catch (e) {
    console.error(e.message);
    res.status(502).json({ error: 'Picture failed. Credits returned.', ...(await refund(req.uid, IMAGE_COST)) });
  }
}));

// scene video (Runway): start
app.post('/api/movie/:id/scene/:i/video', requireAuth, wrapAsync(async (req, res) => {
  const ctx = await loadScene(req, res); if (!ctx) return;
  if (!ctx.s.image) return res.status(400).json({ error: 'Make the picture first.' });
  if (ctx.s.status === 'working') return res.status(409).json({ error: 'This clip is already being made.' });
  const s = await spend(req.uid, VIDEO_COST);
  if (!s.ok) return outOfCredits(res, s.view, VIDEO_COST);
  try {
    const r = await fetch(`${RUNWAY}/image_to_video`, { method: 'POST', headers: RH(),
      body: JSON.stringify({ model: 'gen3a_turbo', promptImage: ctx.s.image, promptText: wrap(ctx.s.visual), duration: 5, ratio: '1280:768' }) });
    if (!r.ok) throw new Error(`Runway ${r.status}`);
    const j = await r.json();
    await patchScene(ctx.m.id, ctx.i, { taskId: j.id, status: 'working', videoUrl: null });
    res.json({ status: 'working', ...s.view });
  } catch (e) {
    console.error(e.message);
    res.status(502).json({ error: 'Video failed to start. Credits returned.', ...(await refund(req.uid, VIDEO_COST)) });
  }
}));

// scene video: poll
app.get('/api/movie/:id/scene/:i/status', requireAuth, wrapAsync(async (req, res) => {
  const ctx = await loadScene(req, res); if (!ctx) return;
  const s = ctx.s;
  if (s.status !== 'working' || !s.taskId) return res.json({ status: s.status, videoUrl: s.videoUrl });
  const r = await fetch(`${RUNWAY}/tasks/${encodeURIComponent(s.taskId)}`, { headers: RH() });
  if (!r.ok) return res.status(502).json({ error: 'Could not check the clip.' });
  const j = await r.json();
  if (j.status === 'SUCCEEDED') {
    const videoUrl = j.output && j.output[0];
    await patchScene(ctx.m.id, ctx.i, { status: 'done', videoUrl }, 'working');
    return res.json({ status: 'done', videoUrl });
  }
  if (j.status === 'FAILED' || j.status === 'CANCELLED') {
    const changed = await patchScene(ctx.m.id, ctx.i, { status: 'failed', taskId: null }, 'working');
    const v = changed ? await refund(req.uid, VIDEO_COST) : {};
    return res.json({ status: 'failed', error: 'Clip failed. Credits returned.', ...v });
  }
  res.json({ status: 'working' });
}));

app.post('/api/report', requireAuth, (req, res) => {
  console.log('REPORT user', req.uid, String(req.body.reason || '').slice(0, 300));
  res.json({ message: 'Thank you. We will review this.' });
});
app.delete('/api/account', requireAuth, wrapAsync(async (req, res) => {
  await pool.query('DELETE FROM users WHERE id=$1', [req.uid]); // movies, payments, tasks cascade
  res.json({ message: 'Your account and data have been deleted.' });
}));

const port = process.env.PORT || 3000;
init().then(() => app.listen(port, () => console.log(`DMFA running on ${port}`)))
  .catch(e => { console.error('Database error:', e.message); process.exit(1); });
