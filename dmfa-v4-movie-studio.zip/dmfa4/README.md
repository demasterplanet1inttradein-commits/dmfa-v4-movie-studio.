# De-Master Flow AI v4: AI movie studio

Write an idea or script, get editable scenes, make a picture and a 5-second clip for each scene, then play them as one movie with narration.

## Credits
- New accounts start with 5000 credits. When credits run out, a 12-hour wait gives REFILL_CREDITS (default 500). Or buy a pack / Pro.
- Costs: plan 5, picture 10, clip 150 (change in .env). A 5-scene movie is about 805 credits.
- Failed pictures and clips are refunded.
- IMPORTANT: every clip costs you real money at Runway, and pictures at Stability. 5000 free credits is about 33 clips per signup. Check their current prices and raise VIDEO_COST or lower FREE_CREDITS if needed.

## Deploy
1. Free Postgres (Supabase or Render). Copy the connection string.
2. Upload this folder to a PRIVATE GitHub repo (never upload .env).
3. Render: New > Web Service. Build `npm install`, start `npm start`.
4. Add variables from .env.example. Required: DATABASE_URL, JWT_SECRET, STABILITY_API_KEY, RUNWAY_API_KEY, PAYSTACK_SECRET_KEY, PUBLIC_URL, PRIVACY_URL. Optional ANTHROPIC_API_KEY for smart scene planning.
5. Paystack webhook: PUBLIC_URL/api/pay/webhook
6. Test with the Paystack TEST key first.

## Notes
- Without ANTHROPIC_API_KEY the script is split into scenes by paragraphs/sentences.
- Runway clip links can expire after a day or two. Users should save clips. (Storing videos permanently needs file storage such as S3, a later upgrade.)
- Clips are separate 5-second videos played one after another. Joining them into one MP4 file is a later upgrade.
- Not included: password reset by email, Google Play Billing.
