// Basic kid-safety prompt filter. Extend this list as needed.
const BLOCKED = ['nude','naked','sex','porn','gore','blood','kill','murder','suicide','weapon','gun','drug','cocaine','heroin','terror','bomb','rape','nsfw','erotic','hate'];
function checkPrompt(p, max = 500) {
  if (typeof p !== 'string') return 'Prompt is required.';
  const t = p.trim();
  if (t.length < 3) return 'Prompt is too short.';
  if (t.length > max) return `Text is too long (max ${max} characters).`;
  const low = t.toLowerCase();
  if (BLOCKED.some(w => new RegExp('\\b' + w + '\\b').test(low))) return 'This prompt is not allowed in a kids app. Please try something friendly.';
  return null;
}
// Always steer outputs to be child-friendly.
const wrap = p => `${p.trim()}, cute, colorful, child-friendly 3D animation style, family safe`;
module.exports = { checkPrompt, wrap };
