// Credit rules on plain user objects. db.withUser() loads and saves them.
const FREE = +process.env.FREE_CREDITS || 5000;         // one-time signup credits
const REFILL = +process.env.REFILL_CREDITS || 500;      // credits after a 12h wait
const COOLDOWN_MS = (+process.env.COOLDOWN_HOURS || 12) * 3600 * 1000;
const PRO_CREDITS = +process.env.PRO_MONTHLY_CREDITS || 30000;
const MIN_COST = +process.env.MIN_COST || 5;            // cheapest action; below this a free user must wait
const MONTH_MS = 30 * 24 * 3600 * 1000;

function refresh(u) {
  const now = Date.now();
  if (u.plan === 'pro' && now > u.proUntil) { u.plan = 'free'; }
  if (u.plan === 'pro' && now >= u.proRefillAt) { u.credits = Math.max(u.credits, PRO_CREDITS); u.proRefillAt = now + MONTH_MS; }
  if (u.plan === 'free' && u.lockedUntil && now >= u.lockedUntil) { u.credits = Math.max(u.credits, REFILL); u.lockedUntil = 0; }
  return u;
}
function view(u) {
  refresh(u);
  return {
    plan: u.plan, credits: u.credits, email: u.email,
    waitSeconds: u.lockedUntil ? Math.max(0, Math.ceil((u.lockedUntil - Date.now()) / 1000)) : 0,
    proUntil: u.plan === 'pro' ? u.proUntil : null
  };
}
function lockIfEmpty(u) { if (u.plan === 'free' && u.credits < MIN_COST && !u.lockedUntil) u.lockedUntil = Date.now() + COOLDOWN_MS; }
function spend(u, cost) {
  refresh(u);
  if (u.plan === 'free' && u.lockedUntil) return { ok: false, reason: 'cooldown' };
  if (u.credits < cost) { lockIfEmpty(u); return { ok: false, reason: u.lockedUntil ? 'cooldown' : 'insufficient' }; }
  u.credits -= cost;
  lockIfEmpty(u);
  return { ok: true };
}
function refund(u, cost) { u.credits += cost; if (u.plan === 'free' && u.credits >= MIN_COST) u.lockedUntil = 0; }
function grantPro(u, expiryMs) { u.plan = 'pro'; u.proUntil = expiryMs; u.credits = Math.max(u.credits, 0) + PRO_CREDITS; u.proRefillAt = Date.now() + MONTH_MS; u.lockedUntil = 0; }
function addCredits(u, n) { refresh(u); u.credits += n; if (u.credits >= MIN_COST) u.lockedUntil = 0; }
module.exports = { FREE, REFILL, view, spend, refund, grantPro, addCredits };
