// Turns an idea or script into a list of scenes. Uses Claude if ANTHROPIC_API_KEY is set, else splits the text.
const clip = (s, n) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);

async function planWithClaude(idea, n, style) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: process.env.PLAN_MODEL || 'claude-sonnet-4-6', max_tokens: 2500,
      system: 'You turn an idea or script into a short, family-friendly animated movie plan. Reply with JSON only, no markdown: {"title":"","scenes":[{"title":"","visual":"","narration":""}]}. Exactly the requested number of scenes. "visual" is one vivid still image under 300 characters; repeat each main character\'s look in every scene so they stay consistent. "narration" is 1 or 2 short sentences read aloud. Never include violence, fear, or adult content.',
      messages: [{ role: 'user', content: `Style: ${style}\nScenes: ${n}\nIdea or script:\n${idea}` }]
    })
  });
  if (!r.ok) throw new Error('Claude ' + r.status);
  const j = await r.json();
  const txt = (j.content || []).map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
  const p = JSON.parse(txt);
  if (!Array.isArray(p.scenes) || !p.scenes.length) throw new Error('bad plan');
  return p;
}

function planBySplitting(idea, n) {
  let parts = idea.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
  if (parts.length < 2) parts = idea.split(/(?<=[.!?])\s+/).map(x => x.trim()).filter(Boolean);
  while (parts.length > n) { // merge neighbours until we fit
    let i = 0; for (let k = 1; k < parts.length - 1; k++) if (parts[k].length < parts[i].length) i = k;
    const j = i + 1 < parts.length ? i + 1 : i - 1; const [a, b] = [Math.min(i, j), Math.max(i, j)];
    parts.splice(a, 2, parts[a] + ' ' + parts[b]);
  }
  return { title: clip(idea, 40) || 'My Movie', scenes: parts.map((t, i) => ({ title: `Scene ${i + 1}`, visual: t, narration: t })) };
}

async function makePlan(idea, n, style) {
  let p;
  if (process.env.ANTHROPIC_API_KEY) { try { p = await planWithClaude(idea, n, style); } catch (e) { console.error('plan fallback:', e.message); } }
  if (!p) p = planBySplitting(idea, n);
  return {
    title: clip(p.title, 80) || 'My Movie',
    style,
    scenes: p.scenes.slice(0, n).map((s, i) => ({
      title: clip(s.title, 60) || `Scene ${i + 1}`, visual: clip(s.visual, 480), narration: clip(s.narration, 300),
      image: null, taskId: null, status: 'idle', videoUrl: null
    }))
  };
}
module.exports = { makePlan, clip };
