const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false },
  max: 10
});

async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      pass_hash TEXT NOT NULL,
      credits INT NOT NULL,
      plan TEXT NOT NULL DEFAULT 'free',
      locked_until BIGINT NOT NULL DEFAULT 0,
      pro_until BIGINT NOT NULL DEFAULT 0,
      pro_refill_at BIGINT NOT NULL DEFAULT 0,
      created_at BIGINT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS payments (
      reference TEXT PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      pack TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at BIGINT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS movies (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      data JSONB NOT NULL,
      created_at BIGINT NOT NULL,
      updated_at BIGINT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tasks (
      task_id TEXT PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      cost INT NOT NULL,
      created_at BIGINT NOT NULL
    );
  `);
}

const toObj = r => ({
  id: +r.id, email: r.email, credits: r.credits, plan: r.plan,
  lockedUntil: +r.locked_until, proUntil: +r.pro_until, proRefillAt: +r.pro_refill_at
});

// Runs fn(user, client) inside a transaction with the user's row locked,
// so two requests can never spend the same credits twice. Saves changes on success.
async function withUser(id, fn) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const r = await c.query('SELECT * FROM users WHERE id=$1 FOR UPDATE', [id]);
    if (!r.rows[0]) { const e = new Error('Account not found.'); e.status = 401; throw e; }
    const u = toObj(r.rows[0]);
    const out = await fn(u, c);
    await c.query('UPDATE users SET credits=$2, plan=$3, locked_until=$4, pro_until=$5, pro_refill_at=$6 WHERE id=$1',
      [u.id, u.credits, u.plan, u.lockedUntil, u.proUntil, u.proRefillAt]);
    await c.query('COMMIT');
    return out;
  } catch (e) {
    try { await c.query('ROLLBACK'); } catch {}
    throw e;
  } finally { c.release(); }
}

module.exports = { pool, init, withUser };
