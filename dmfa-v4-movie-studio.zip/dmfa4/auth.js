const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { pool, withUser } = require('./db');
const C = require('./credits');

const SECRET = process.env.JWT_SECRET;
const sign = id => jwt.sign({ sub: String(id) }, SECRET, { expiresIn: '30d' });

function requireAuth(req, res, next) {
  const m = /^Bearer (.+)$/.exec(req.get('authorization') || '');
  if (!m) return res.status(401).json({ error: 'Please log in.' });
  try { req.uid = +jwt.verify(m[1], SECRET).sub; next(); }
  catch { res.status(401).json({ error: 'Session expired. Please log in again.' }); }
}

const router = express.Router();
router.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } }));

const okEmail = e => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e.length <= 200;

router.post('/signup', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const pw = String(req.body.password || '');
  if (!okEmail(email)) return res.status(400).json({ error: 'Enter a valid email.' });
  if (pw.length < 8 || pw.length > 100) return res.status(400).json({ error: 'Password must be 8 to 100 characters.' });
  if (req.body.adult !== true) return res.status(400).json({ error: 'Accounts are for parents and guardians (18+).' });
  try {
    const hash = await bcrypt.hash(pw, 10);
    const r = await pool.query('INSERT INTO users (email, pass_hash, credits, created_at) VALUES ($1,$2,$3,$4) RETURNING id', [email, hash, C.FREE, Date.now()]);
    const id = r.rows[0].id;
    const view = await withUser(id, u => C.view(u));
    res.json({ token: sign(id), ...view });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'That email already has an account. Log in instead.' });
    console.error('signup', e.message); res.status(500).json({ error: 'Could not create account.' });
  }
});

router.post('/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const pw = String(req.body.password || '');
  try {
    const r = await pool.query('SELECT id, pass_hash FROM users WHERE email=$1', [email]);
    const row = r.rows[0];
    if (!row || !(await bcrypt.compare(pw, row.pass_hash))) return res.status(401).json({ error: 'Wrong email or password.' });
    const view = await withUser(row.id, u => C.view(u));
    res.json({ token: sign(row.id), ...view });
  } catch (e) { console.error('login', e.message); res.status(500).json({ error: 'Could not log in.' }); }
});

module.exports = { router, requireAuth };
