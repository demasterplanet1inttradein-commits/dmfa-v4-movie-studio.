const $ = id => document.getElementById(id);
let token = localStorage.getItem('dmfa_token'), cfg = {}, state = {}, tick = null, selPack = null, signup = false;
let movie = null, busy = false;

async function api(path, opts = {}) {
  const h = { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) };
  const r = await fetch(path, { ...opts, headers: h });
  let j = {}; try { j = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(j.error || 'Something went wrong.'); e.data = j; e.status = r.status; throw e; }
  return j;
}
const post = (p, b) => api(p, { method: 'POST', body: JSON.stringify(b || {}) });
const sleep = ms => new Promise(r => setTimeout(r, ms));
function toast(m) { const t = $('toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(t._h); t._h = setTimeout(() => t.style.display = 'none', 3800); }
const fmt = s => [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(n => String(n).padStart(2, '0')).join(':');
const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------- accounts ----------
function showAuth(on) { $('authCard').classList.toggle('hide', !on); $('appArea').classList.toggle('hide', on); $('btnDelete').classList.toggle('hide', on); $('btnReport').classList.toggle('hide', on); }
function logout() { token = null; localStorage.removeItem('dmfa_token'); clearInterval(tick); showAuth(true); }
function setMode(s) {
  signup = s; $('authTitle').textContent = s ? 'Create your account' : 'Welcome back';
  $('btnAuth').textContent = s ? 'Create account' : 'Log in';
  $('btnSwitch').textContent = s ? 'Have an account? Log in' : 'New here? Create an account';
  $('aTermsRow').classList.toggle('hide', !s);
}
$('btnSwitch').onclick = () => setMode(!signup);
$('btnAuth').onclick = async () => {
  $('btnAuth').disabled = true;
  try {
    const j = await post('/api/auth/' + (signup ? 'signup' : 'login'), { email: $('aEmail').value, password: $('aPass').value, adult: $('aTerms').checked });
    token = j.token; localStorage.setItem('dmfa_token', token); $('aPass').value = '';
    showAuth(false); render(j); loadMovies(); await checkPayment();
  } catch (e) { toast(e.message); }
  $('btnAuth').disabled = false;
};
$('btnOut').onclick = logout;

// ---------- credits ----------
function render(s) {
  if (!s || s.credits === undefined) return;
  state = s; $('credits').textContent = s.credits.toLocaleString(); $('who').textContent = s.email || '';
  $('plan').textContent = s.plan === 'pro' ? 'PRO' : 'FREE'; $('plan').className = 'badge' + (s.plan === 'pro' ? ' pro' : '');
  clearInterval(tick);
  const locked = s.plan === 'free' && s.waitSeconds > 0;
  $('lockCard').classList.toggle('hide', !locked);
  if (locked) {
    let left = s.waitSeconds; $('timer').textContent = fmt(left);
    tick = setInterval(async () => { left--; $('timer').textContent = fmt(Math.max(left, 0));
      if (left <= 0) { clearInterval(tick); try { render(await api('/api/credits')); toast('Your credits are back! 🎉'); } catch {} } }, 1000);
  }
}
function handleErr(e) {
  if (e.status === 401) { logout(); return toast(e.message); }
  if (e.data && e.data.credits !== undefined) render(e.data);
  toast(e.message);
}

// ---------- movies list ----------
async function loadMovies() {
  try {
    const { movies } = await api('/api/movies');
    $('movies').innerHTML = movies.length ? '' : 'No movies yet. Start one above!';
    movies.forEach(m => { const d = document.createElement('div'); d.className = 'mv';
      d.innerHTML = `<div><b>${esc(m.title)}</b><div class="mut">${m.scenes} scenes</div></div><span>›</span>`;
      d.onclick = () => openMovie(m.id); $('movies').appendChild(d); });
  } catch (e) { handleErr(e); }
}
$('btnPlan').onclick = async () => {
  const idea = $('idea').value.trim(); if (idea.length < 3) return toast('Type your idea or script first.');
  $('btnPlan').disabled = true; $('btnPlan').textContent = 'Planning your scenes…';
  try { const j = await post('/api/movie/plan', { idea, style: $('style').value, scenes: +$('nscenes').value }); render(j); movie = j; showEditor(); }
  catch (e) { handleErr(e); }
  $('btnPlan').disabled = false; $('btnPlan').textContent = '✨ Plan my movie';
};
async function openMovie(id) { try { movie = await api('/api/movie/' + id); showEditor(); } catch (e) { handleErr(e); } }
$('btnBack').onclick = () => { $('editor').classList.add('hide'); $('home').classList.remove('hide'); loadMovies(); };
$('btnDelMovie').onclick = async () => { if (!confirm('Delete this movie?')) return; try { await api('/api/movie/' + movie.id, { method: 'DELETE' }); $('btnBack').onclick(); } catch (e) { handleErr(e); } };

// ---------- editor ----------
function showEditor() {
  $('home').classList.add('hide'); $('editor').classList.remove('hide'); $('mTitle').textContent = movie.title;
  $('scenes').innerHTML = ''; movie.scenes.forEach((_, i) => $('scenes').appendChild(sceneEl(i)));
}
function sceneEl(i) {
  const s = movie.scenes[i], c = cfg.costs || {}, el = document.createElement('div'); el.className = 'card scene'; el.id = 'sc' + i;
  const working = s.status === 'working';
  el.innerHTML = `<div class="row"><b>${i + 1}. ${esc(s.title)}</b><span class="mut">${working ? '⏳ making clip…' : s.status === 'done' ? '✅ clip ready' : s.image ? '🖼 picture ready' : ''}</span></div>
    ${s.videoUrl ? `<video src="${esc(s.videoUrl)}" controls playsinline poster="${s.image || ''}"></video><a class="mut" href="${esc(s.videoUrl)}" target="_blank" rel="noopener" download>⬇ Save clip</a>`
      : s.image ? `<img class="th" src="${s.image}" alt="">` : `<div class="ph">No picture yet</div>`}
    <textarea class="vis" maxlength="480" placeholder="What we see">${esc(s.visual)}</textarea>
    <textarea class="nar" maxlength="300" placeholder="Narration (read aloud)">${esc(s.narration)}</textarea>
    <div class="two"><button class="alt sm" data-a="img">🖼 Picture (${c.image || 10})</button><button class="sm" data-a="vid" ${s.image ? '' : 'disabled'}>🎥 Clip (${c.video || 150})</button></div>`;
  el.querySelectorAll('textarea').forEach(t => t.onchange = () => saveText(i));
  el.querySelector('[data-a=img]').onclick = () => run(() => genImage(i));
  el.querySelector('[data-a=vid]').onclick = () => run(() => genVideo(i));
  if (working) pollClip(i).catch(handleErr);
  return el;
}
function redraw(i) { const old = $('sc' + i); old.replaceWith(sceneEl(i)); }
function readText(i) { const el = $('sc' + i); return { visual: el.querySelector('.vis').value.trim(), narration: el.querySelector('.nar').value.trim() }; }
async function saveText(i) {
  const t = readText(i); const s = movie.scenes[i];
  try { await api(`/api/movie/${movie.id}/scene/${i}`, { method: 'PUT', body: JSON.stringify({ title: s.title, ...t }) }); Object.assign(s, t); } catch (e) { handleErr(e); }
}
async function run(fn) { if (busy) return toast('Please wait, still working…'); busy = true; try { await fn(); } catch (e) { handleErr(e); } busy = false; }

async function genImage(i) {
  const s = movie.scenes[i], t = readText(i); Object.assign(s, t);
  const btn = $('sc' + i).querySelector('[data-a=img]'); btn.textContent = 'Drawing…'; btn.disabled = true;
  try { const j = await post(`/api/movie/${movie.id}/scene/${i}/image`, { visual: t.visual }); render(j); Object.assign(s, { image: j.image, status: 'idle', videoUrl: null, taskId: null }); }
  finally { redraw(i); }
}
async function genVideo(i) {
  const s = movie.scenes[i]; await saveText(i);
  const j = await post(`/api/movie/${movie.id}/scene/${i}/video`); render(j); s.status = 'working'; redraw(i);
  await pollClip(i);
}
async function pollClip(i) {
  const s = movie.scenes[i];
  for (let n = 0; n < 120; n++) {
    await sleep(5000);
    const p = await api(`/api/movie/${movie.id}/scene/${i}/status`);
    if (p.status === 'done') { s.status = 'done'; s.videoUrl = p.videoUrl; redraw(i); return; }
    if (p.status === 'failed') { s.status = 'failed'; render(p); redraw(i); toast(p.error || 'Clip failed. Credits returned.'); return; }
  }
  toast('This clip is taking long. Reopen the movie in a few minutes.');
}
$('btnAll').onclick = () => run(async () => {
  $('btnAll').disabled = true;
  try {
    for (let i = 0; i < movie.scenes.length; i++) {
      $('mHint').textContent = `Making scene ${i + 1} of ${movie.scenes.length}… keep this page open.`;
      if (!movie.scenes[i].image) await genImage(i);
      if (movie.scenes[i].status !== 'done') await genVideo(i);
    }
    toast('Your movie is ready! Tap Play movie. 🎉');
  } finally { $('mHint').textContent = 'Edit any scene, then make pictures and clips. Save your clips: video links may expire after a day or two.'; $('btnAll').disabled = false; }
});

// ---------- player ----------
let pk = 0, pTimer = null;
function speak(t) { try { speechSynthesis.cancel(); if ($('plVoice').checked && t) speechSynthesis.speak(new SpeechSynthesisUtterance(t)); } catch {} }
function playAt(k) {
  clearTimeout(pTimer); const list = movie.scenes; if (k < 0) k = 0; if (k >= list.length) { $('cap').textContent = 'The End 🎬'; $('plVid').pause(); return; }
  pk = k; const s = list[k]; $('cap').textContent = s.narration || s.title; speak(s.narration);
  const v = $('plVid'), im = $('plImg');
  if (s.videoUrl) { im.classList.add('hide'); v.classList.remove('hide'); v.src = s.videoUrl; v.onended = () => playAt(pk + 1); v.play().catch(() => {}); }
  else { v.pause(); v.classList.add('hide'); im.classList.remove('hide'); im.src = s.image || ''; pTimer = setTimeout(() => playAt(pk + 1), 4500); }
}
$('btnPlay').onclick = () => { $('plTitle').textContent = movie.title; $('player').classList.remove('hide'); playAt(0); };
$('plClose').onclick = () => { clearTimeout(pTimer); $('plVid').pause(); try { speechSynthesis.cancel(); } catch {} $('player').classList.add('hide'); };
$('plNext').onclick = () => playAt(pk + 1); $('plPrev').onclick = () => playAt(pk - 1);

// ---------- payments ----------
function openBuy() {
  const box = $('packs'); box.innerHTML = '';
  (cfg.packs || []).forEach(p => {
    const d = document.createElement('div'); d.className = 'pack' + (p.pro ? ' pro' : '');
    const price = new Intl.NumberFormat(undefined, { style: 'currency', currency: cfg.currency, maximumFractionDigits: 0 }).format(p.amount);
    d.innerHTML = `<div><b>${p.pro ? '👑 ' : ''}${p.label}</b><div class="mut">${p.pro ? 'Big monthly credits, no waiting' : p.credits.toLocaleString() + ' credits'}</div></div><b>${price}</b>`;
    d.onclick = () => { selPack = p.id; [...box.children].forEach(c => c.classList.remove('sel')); d.classList.add('sel'); }; box.appendChild(d);
  });
  $('buyModal').classList.remove('hide');
}
$('btnBuy').onclick = openBuy; $('btnUpgrade').onclick = openBuy; $('closeBuy').onclick = () => $('buyModal').classList.add('hide');
$('btnPay').onclick = async () => {
  if (!selPack) return toast('Choose a pack first.'); $('btnPay').disabled = true;
  try { const j = await post('/api/pay/init', { pack: selPack }); localStorage.setItem('dmfa_ref', j.reference); location.href = j.url; } catch (e) { handleErr(e); }
  $('btnPay').disabled = false;
};
async function checkPayment() {
  const q = new URLSearchParams(location.search), ref = q.get('reference') || q.get('trxref') || localStorage.getItem('dmfa_ref'); if (!ref) return;
  try {
    const j = await post('/api/pay/verify', { reference: ref });
    if (j.status === 'success') { toast(j.message); localStorage.removeItem('dmfa_ref'); }
    else if (j.status === 'failed' || j.status === 'ignored') localStorage.removeItem('dmfa_ref');
    else toast('Payment is still processing. Refresh in a moment.');
    render(j);
  } catch (e) { handleErr(e); }
  if (q.has('reference') || q.has('trxref')) history.replaceState({}, '', location.pathname);
}

// ---------- safety & privacy ----------
$('btnReport').onclick = async () => { try { const j = await post('/api/report', { reason: 'Reported content' + (movie ? ' in movie ' + movie.id : '') }); toast(j.message); } catch (e) { handleErr(e); } };
$('btnDelete').onclick = async () => {
  if (!confirm('Delete your account, movies and credits? This cannot be undone.')) return;
  try { await api('/api/account', { method: 'DELETE' }); logout(); localStorage.clear(); toast('Your account was deleted.'); } catch (e) { handleErr(e); }
};

(async function init() {
  try { cfg = await api('/api/config'); } catch { return toast('Cannot reach the server. Check your connection.'); }
  $('style').innerHTML = (cfg.styles || []).map(s => `<option>${esc(s)}</option>`).join('');
  if (cfg.privacyUrl) $('privLink').href = cfg.privacyUrl; else $('privLink').classList.add('hide');
  if (!token) return showAuth(true);
  try { showAuth(false); render(await api('/api/credits')); loadMovies(); await checkPayment(); } catch (e) { if (e.status === 401) logout(); else toast(e.message); }
})();
